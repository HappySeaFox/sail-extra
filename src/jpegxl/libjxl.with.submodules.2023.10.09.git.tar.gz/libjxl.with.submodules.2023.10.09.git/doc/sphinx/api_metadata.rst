Image and frame metadata
========================

.. doxygengroup:: libjxl_metadata
   :members:
   :private-members:
