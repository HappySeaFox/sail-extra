.. libjxl sphinx documentation entrypoint

JPEG XL image format reference implementation
=============================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

