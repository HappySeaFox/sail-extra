# C API for resvg

## Build

```sh
cargo build --release
```

This will produce a dynamic C library that can be found at `../target/release`.
